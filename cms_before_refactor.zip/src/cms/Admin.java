package cms;

public class Admin {
	private String name;
	private String adminId;
}
