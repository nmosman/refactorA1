package cms;

public class User {

	private String username;
	private String name;
	private String address;
	private String userType;
	
	private Permissions p;
	
	
}
