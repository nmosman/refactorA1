package cms;

import static org.junit.Assert.*;

import org.junit.Test;

public class DbAPITest {

	@Test
	public void testPopulateCache() {
		fail("Not yet implemented");
	}

	@Test
	public void testLogin() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddCourse() {
		fail("Not yet implemented");
	}

	@Test
	public void testFindCourse() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testGetStudentSchedule()
	{
		DbAPI db = new DbAPI();
		
		String username = "student";
		
		StudentSchedule s = db.getStudentSchedule(username);
		
		assertNotEquals(s, null);
	}

}
