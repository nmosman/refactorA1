package cms;

import static org.junit.Assert.*;

import org.junit.Test;

public class CourseTest {

	@Test
	public void testCourse() {
		fail("Not yet implemented");
	}

	@Test
	public void testCourseInfo() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetClass_size_max() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetClass_size_max() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetStudentList() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetStudentList() {
		fail("Not yet implemented");
	}

}
