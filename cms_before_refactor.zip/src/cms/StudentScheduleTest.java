package cms;

import static org.junit.Assert.*;

import org.junit.Test;

public class StudentScheduleTest {

	

	@Test
	public void testAddCourse() {
		
		StudentSchedule s = new StudentSchedule();
		Course c = new Course("Test", "TestID");
		s.addCourse(c);
		
		assertEquals(c, s.getSchedule().get(0));
	
	}

}
