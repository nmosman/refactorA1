package cms;

public class Permissions {

	private String permissionType;
	
	public Permissions(String p)
	{
		permissionType = p;
	}
	
	
	public String getPermissionType()
	{
		return permissionType;
	}
}
