package cms;

import java.util.ArrayList;
import java.util.Date;

public class CourseSession {

	private Date startDate;
	private Date endDate; 
	
	private int class_size_max;
	
	private ArrayList<Student> studentList = new ArrayList<Student>();
	
}
